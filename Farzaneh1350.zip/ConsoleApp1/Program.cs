﻿using System.Linq;
using System.Text;
namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            byte[] Random = new byte[128];
            System.Security.Cryptography.RandomNumberGenerator rnd = System.Security.Cryptography.RandomNumberGenerator.Create();
            rnd.GetBytes(Random);

            Farzaneh_Cryptosystem_.Farzaneh_ ashdod_ = new Farzaneh_Cryptosystem_.Farzaneh_(5, 5, 5, 5, 5, 5, 5, 5, Random,1002,2001,600, "HI", "IH");
            byte[] bts = ashdod_.DoEncryptIT("tanesh martabe 20 .....".ToCharArray());


            Console.WriteLine(Encoding.UTF8.GetString(bts));

            Farzaneh_Cryptosystem_.Farzaneh_ ashdod_x = new Farzaneh_Cryptosystem_.Farzaneh_(5, 5, 5, 5, 5, 5, 5, 5, Random, 1002, 2001, 600, "HI", "IH6");
            byte[] bts_x = ashdod_x.DoDE_cryptIT(bts);

            string Text22 = Encoding.UTF8.GetString(bts);
            Console.WriteLine($"\n{Text22}\n");
        }
    }
}
namespace Farzaneh_Cryptosystem_
{
    using System;
    using System.Collections.Generic;

    public class Farzaneh_
    {
        RANDOM_BIT_BEL.BEL BEL_ = new RANDOM_BIT_BEL.BEL(128);

        private float q, p, V, w, AlphaV, T, AlphaT; int w2; float SUM_X = 0; string Password_ = "", OVO_ = "";
        private byte[] Password2_ = new byte[128];
        private Int64 SK1;
        private Int64 SK2;
        public Farzaneh_(float q, float p, float V, float w, float AlphaV, float T, float AlphaT, int w2, byte[] PAS2, Int64 SK1_, Int64 SK2_, float SUM_X = 0, string Password_ = "", string OVO_ = "")
        {
            {
                this.q = q;
                this.p = p;
                this.V = V;
                this.w = w;
                this.AlphaV = AlphaV;
                this.T = T;
                this.AlphaT = AlphaT;
                this.Password_ = Password_;
                this.OVO_ = OVO_;
                this.w2 = w2;
                BEL_.BEL_(SK1_, SK2_);
                Password2_ = PAS2;

            }
        }
        public byte[] DoEncryptIT(char[] in1_x)
        {
            if (in1_x.Length > 128)
            {
                throw new ArgumentOutOfRangeException();
            }
            char[] in_x;
            in_x = in1_x;

            byte[] R1 = Odessa_512_hash_function.Class1.Generator(Password_, null);
            Odessa_512_hash_function.Class1.array.Clear();
            byte[] R2 = Odessa_512_hash_function.Class1.Generator(null, R1);
            Odessa_512_hash_function.Class1.array.Clear();
            byte[] R3 = Odessa_512_hash_function.Class1.Generator(null, R2);
            Odessa_512_hash_function.Class1.array.Clear();
            byte[] R4 = Odessa_512_hash_function.Class1.Generator(null, R3);
            Odessa_512_hash_function.Class1.array.Clear();
            byte[] R5 = Odessa_512_hash_function.Class1.Generator(null, R4);
            Odessa_512_hash_function.Class1.array.Clear();
            byte[] R6 = Odessa_512_hash_function.Class1.Generator(null, R5);
            Odessa_512_hash_function.Class1.array.Clear();
            byte[] R7 = Odessa_512_hash_function.Class1.Generator(null, R6);
            Odessa_512_hash_function.Class1.array.Clear();
            {
                GC.WaitForFullGCComplete();
                byte[] inputs_x = new byte[128];
                int i__ = 0;
                for (; i__ < 128; i__++)
                {
                    try
                    {
                        inputs_x[i__] = (byte)in_x[i__];
                    }
                    catch (Exception)
                    {
                        break;
                    }
                }
                for (; i__ < 128; i__++)
                {
                    inputs_x[i__] = 0;
                }
                // ROUND ONE
                {
                    int KEY = ((int)((V + (SUM_X + AlphaT) + SUM_X + q + Math.Log10(p) + Math.Pow(w, w2)) * Math.Log10(w)));
                    byte[] list = new byte[128];
                    System.Random rnd = new System.Random((int)KEY);
                    // First Round XOR
                    {
                        for (int i = 0; i < 128; i++)
                        {
                            rnd.NextBytes(list);
                        }
                        for (int i = 0; i < 128; i++)
                        {
                            inputs_x[i] = (byte)((byte)inputs_x[i] ^ (byte)list[i]);
                            inputs_x[i] = (byte)((byte)inputs_x[i] ^ (byte)R1[i]);
                        }
                    }
                    // ROUND TWO - ~
                    {
                        {
                            SUM_X = (float)KEY; q *= 2; AlphaT += T; V += AlphaV;
                            KEY = ((int)((V + (SUM_X + AlphaT) + SUM_X + q + Math.Log10(p) + Math.Pow(w, w2)) * Math.Log10(w)));
                            list = new byte[128];
                            rnd = new System.Random((int)KEY);
                            // Round XOR
                            {
                                for (int i = 0; i < 128; i++)
                                {
                                    rnd.NextBytes(list);
                                }
                                for (int i = 0; i < 128; i++)
                                {
                                    inputs_x[i] = (byte)((byte)inputs_x[i] ^ (byte)list[i]);
                                    inputs_x[i] = (byte)((byte)inputs_x[i] ^ (byte)R2[i]);
                                }
                            }
                        }
                    }
                    {
                        {
                            SUM_X = (float)KEY; q *= 2; AlphaT += T; V += AlphaV;
                            KEY = ((int)((V + (SUM_X + AlphaT) + SUM_X + q + Math.Log10(p) + Math.Pow(w, w2)) * Math.Log10(w)));
                            list = new byte[128];
                            rnd = new System.Random((int)KEY);
                            // Round XOR
                            {
                                for (int i = 0; i < 128; i++)
                                {
                                    rnd.NextBytes(list);
                                }
                                for (int i = 0; i < 128; i++)
                                {
                                    inputs_x[i] = (byte)((byte)inputs_x[i] ^ (byte)list[i]);
                                    inputs_x[i] = (byte)((byte)inputs_x[i] ^ (byte)R3[i]);
                                    inputs_x[i] = (byte)((byte)inputs_x[i] ^ (byte)R4[i]);
                                    inputs_x[i] = (byte)((byte)inputs_x[i] ^ (byte)R5[i]);
                                    inputs_x[i] = (byte)((byte)inputs_x[i] ^ (byte)R6[i]);
                                    inputs_x[i] = (byte)((byte)inputs_x[i] ^ (byte)R7[i]);
                                }
                            }
                        }
                    }
                }
                // Print Output
                {
                    {
                        Odessa_512_hash_function.Class1.array.Clear();
                        byte[] OVO_Byte = Odessa_512_hash_function.Class1.Generator(OVO_, null);
                        Odessa_512_hash_function.Class1.array.Clear();
                        for (int i = 0; i < 128; i++)
                        {
                            inputs_x[i] = (byte)((byte)inputs_x[i] ^ OVO_Byte[i]);
                        }
                        Odessa_512_hash_function.Class1.array.Clear();
                        OVO_Byte = Odessa_512_hash_function.Class1.Generator(null, OVO_Byte);
                        for (int i = 0; i < 128; i++)
                        {
                            inputs_x[i] = (byte)((byte)inputs_x[i] ^ OVO_Byte[i]);
                        }

                        #region FinalEnc
                        {
                            Odessa_512_hash_function.Class1.array.Clear();
                            OVO_Byte = Odessa_512_hash_function.Class1.Generator(null, OVO_Byte);
                            for (int ZZ = 0; ZZ < 128; ZZ++)
                            {
                                Password2_[ZZ] = (byte)((dynamic)Password2_[ZZ] ^ (dynamic)BEL_.lst_of_bits[ZZ]);
                            }
                            for (int i = 0; i < 128; i++)
                            {
                                inputs_x[i] = (byte)((byte)inputs_x[i] ^ Password2_[i]);
                            }
                            BEL_ = new RANDOM_BIT_BEL.BEL(128);
                            BEL_.BEL_(SK2, SK1);
                            for (int ZZ = 0; ZZ < 128; ZZ++)
                            {
                                Password2_[ZZ] = (byte)((dynamic)Password2_[ZZ] ^ (dynamic)BEL_.lst_of_bits[ZZ]);
                            }
                            for (int i = 0; i < 128; i++)
                            {
                                inputs_x[i] = (byte)((byte)inputs_x[i] ^ Password2_[i]);
                                inputs_x[i] = (byte)((byte)inputs_x[i] ^ OVO_Byte[i]);
                            }
                        }
                        #endregion

                    }
                }
                return inputs_x;
            }
        }
        public byte[] DoDE_cryptIT(byte[] in_x)
        {
            {
                {
                    byte[] Password1 = new byte[32];
                    byte[] Password2 = new byte[32];
                    byte[] OVO_Byte1 = Odessa_512_hash_function.Class1.Generator(OVO_, null);
                    byte[] OVO_Byte2 = Odessa_512_hash_function.Class1.Generator(null, OVO_Byte1);
                    byte[] OVO_Byte3 = Odessa_512_hash_function.Class1.Generator(null, OVO_Byte2);
                    for (int i = 0; i < 128; i++)
                    {
                        in_x[i] = (byte)((byte)in_x[i] ^ OVO_Byte3[i]);
                        in_x[i] = (byte)((byte)in_x[i] ^ Password2_[i]);
                    }
                    BEL_ = new RANDOM_BIT_BEL.BEL(128);
                    BEL_.BEL_(SK2, SK1);
                    for (int ZZ = 0; ZZ < 128; ZZ++)
                    {
                        Password2_[ZZ] = (byte)((dynamic)Password2_[ZZ] ^ (dynamic)BEL_.lst_of_bits[ZZ]);
                    }
                    #region FinalEnc
                    {
                        for (int i = 0; i < 128; i++)
                        {
                            in_x[i] = (byte)((byte)in_x[i] ^ Password2_[i]);
                        }

                        for (int ZZ = 0; ZZ < 128; ZZ++)
                        {
                            Password2_[ZZ] = (byte)((dynamic)Password2_[ZZ] ^ (dynamic)BEL_.lst_of_bits[ZZ]);
                        }
                    }
                    #endregion
                    for (int i = 0; i < 128; i++)
                    {
                        in_x[i] = (byte)((byte)in_x[i] ^ OVO_Byte2[i]);
                    }
                    for (int i = 0; i < 128; i++)
                    {
                        in_x[i] = (byte)((byte)in_x[i] ^ OVO_Byte1[i]);
                    }
                }
            }
            return new byte[0];
        }
    }
}