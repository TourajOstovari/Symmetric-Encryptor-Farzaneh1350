﻿using System.Linq;
using System.Text;

internal class Program
{
    private static void Main()
    {
        string in_x = ""; float q, p, V, w, AlphaV,T,AlphaT; int w2; float SUM_X = 0;
        Console.WriteLine("\nEnter q: (ex: 1.5)\n");
        q = float.Parse(Console.ReadLine());
        Console.WriteLine("\nEnter p: (ex: 2.6)\n");
        p = float.Parse(Console.ReadLine());
        Console.WriteLine("\nEnter w: (55.5)\n");
        w = float.Parse(Console.ReadLine());
        Console.WriteLine("\nEnter V: (1 -- ~)\n");
        V = float.Parse(Console.ReadLine());
        Console.WriteLine("\nEnter Alpha V: (1 -- ~)\n");
        AlphaV = float.Parse(Console.ReadLine());
        Console.WriteLine("\nEnter T: (1 -- ~)\n");
        T = float.Parse(Console.ReadLine());
        Console.WriteLine("\nEnter Alpha T: (1 -- ~)\n");
        AlphaT = float.Parse(Console.ReadLine());
        w2 = (int)w % 2;


        System.Collections.ArrayList list = new System.Collections.ArrayList();

        Console.WriteLine("\n::Processing KEYS::\n");
        while (true)
        {
            dynamic KEY = ((V + (SUM_X + AlphaT) + SUM_X + q + Math.Log10(p) + Math.Pow(w, w2)) * Math.Log10(w)) / T;
            Console.WriteLine(KEY);
            if (!list.Contains(KEY))
                list.Add(KEY);
            else
            {
                q *= 2; p *= 2;
                w *= 2; V += AlphaV;
            }
            System.IO.File.AppendAllText(@"D:\Rands.txt",KEY.ToString()+"\n");
            Console.Title = list.Count.ToString();
            SUM_X = (float)KEY;
        }
        Console.WriteLine("count: " + list.Count);




    }
}
