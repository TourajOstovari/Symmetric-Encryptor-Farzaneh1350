﻿namespace IRDragon;
using System;
using System.Text;
internal class Decryption
{
    public void Dec()
    {
        //Char[] in_x = new char[128];
        byte[] in_x = new byte[128];
        float q, p, V, w, AlphaV, T, AlphaT; int w2; float SUM_X = 0; string Password_ = "";
        Console.WriteLine("\n Enter q: (ex: 1.5)\n");
        q = float.Parse(Console.ReadLine());
        Console.WriteLine("\nEnter p: (ex: 2.6)\n");
        p = float.Parse(Console.ReadLine());
        Console.WriteLine("\nEnter w: (55.5)\n");
        w = float.Parse(Console.ReadLine());
        Console.WriteLine("\nEnter V: (1 -- ~)\n");
        V = float.Parse(Console.ReadLine());
        Console.WriteLine("\nEnter Alpha V: (1 -- ~)\n");
        AlphaV = float.Parse(Console.ReadLine());
        Console.WriteLine("\nEnter T: (1 -- ~)\n");
        T = float.Parse(Console.ReadLine());
        Console.WriteLine("\nEnter Alpha T: (1 -- ~)\n");
        AlphaT = float.Parse(Console.ReadLine());
        w2 = (int)w % 2;
        Console.WriteLine("Enter Password: ");
        Password_ = Console.ReadLine();

        string OVO_ = "";
        Console.WriteLine("\nEnter OVO:\n");
        OVO_ = Console.ReadLine();


        byte[] R1 = Odessa_512_hash_function.Class1.Generator(null, UTF8Encoding.UTF8.GetBytes(Password_));
        byte[] R2 = Odessa_512_hash_function.Class1.Generator(null, R1);
        byte[] R3 = Odessa_512_hash_function.Class1.Generator(null, R2);
        byte[] R4 = Odessa_512_hash_function.Class1.Generator(null, R3);
        byte[] R5 = Odessa_512_hash_function.Class1.Generator(null, R4);
        byte[] R6 = Odessa_512_hash_function.Class1.Generator(null, R5);
        byte[] R7 = Odessa_512_hash_function.Class1.Generator(null, R6);


        {
            Console.WriteLine("\nPlease write TEXT here: \n");

        }
        //string[] temp__ = Console.ReadLine().Split("!:~~:!");
        //in_x = temp__[1].ToArray<char>();
        //in_x = Console.ReadLine().ToArray<char>();
        in_x = System.IO.File.ReadAllBytes(@"D:\Encrypted.txt");
        {
            {
                byte[] OVO_Byte = Odessa_512_hash_function.Class1.Generator(OVO_, null);
                for (int i = 0; i < 128; i++)
                {
                    in_x[i] = (byte)((byte)in_x[i] ^ OVO_Byte[i]);
                }
                OVO_Byte = Odessa_512_hash_function.Class1.Generator(null, OVO_Byte);
                for (int i = 0; i < 128; i++)
                {
                    in_x[i] = (byte)((byte)in_x[i] ^ OVO_Byte[i]);
                }
            }
            GC.WaitForFullGCComplete();
            byte[] inputs_x = new byte[128];
            int i__ = 0;
            for (; i__ < 128; i__++)
            {
                try
                {
                    inputs_x[i__] = (byte)in_x[i__];
                }
                catch (Exception)
                {

                    break;
                }
            }
            for (; i__ < 128; i__++)
            {
                inputs_x[i__] = 1;
            }

            {
                Console.WriteLine("\n::Processing::\n");
                dynamic KEY = ((V + (SUM_X + AlphaT) + SUM_X + q + Math.Log10(p) + Math.Pow(w, w2)) * Math.Log10(w));

                byte[] list1 = new byte[128];
                byte[] list2 = new byte[128];
                byte[] list3 = new byte[128];
                
                // First Round XOR
                {
                    System.Random rnd = new System.Random((int)KEY);
                    for (int i = 0; i < 128; i++)
                    {
                        rnd.NextBytes(list1);
                    }
                    SUM_X = (float)KEY; q *= 2; AlphaT += T; V += AlphaV;
                    KEY = ((V + (SUM_X + AlphaT) + SUM_X + q + Math.Log10(p) + Math.Pow(w, w2)) * Math.Log10(w));
                    rnd = new System.Random((int)KEY);
                    for (int i = 0; i < 128; i++)
                    {
                        rnd.NextBytes(list2);
                    }
                    SUM_X = (float)KEY; q *= 2; AlphaT += T; V += AlphaV;
                    KEY = ((V + (SUM_X + AlphaT) + SUM_X + q + Math.Log10(p) + Math.Pow(w, w2)) * Math.Log10(w));
                    rnd = new System.Random((int)KEY);
                    for (int i = 0; i < 128; i++)
                    {
                        rnd.NextBytes(list3);
                    }


                    {
                        {
                            // Round XOR
                            {
                                for (int i = 0; i < 128; i++)
                                {
                                    inputs_x[i] = (byte)((byte)inputs_x[i] ^ (byte)R7[i]);
                                    inputs_x[i] = (byte)((byte)inputs_x[i] ^ (byte)R6[i]);
                                    inputs_x[i] = (byte)((byte)inputs_x[i] ^ (byte)R5[i]);
                                    inputs_x[i] = (byte)((byte)inputs_x[i] ^ (byte)R4[i]);
                                    inputs_x[i] = (byte)((byte)inputs_x[i] ^ (byte)R3[i]);
                                    inputs_x[i] = (byte)((byte)inputs_x[i] ^ (byte)list3[i]);
                                }
                            }
                        }
                    }


                    {
                        {

                            // Round XOR
                            {
                                for (int i = 0; i < 128; i++)
                                {
                                    inputs_x[i] = (byte)((byte)inputs_x[i] ^ (byte)R2[i]);
                                    inputs_x[i] = (byte)((byte)inputs_x[i] ^ (byte)list2[i]);
                                }
                            }
                        }
                    }

                    for (int i = 0; i < 128; i++)
                    {
                        inputs_x[i] = (byte)((byte)inputs_x[i] ^ (byte)R1[i]);
                        inputs_x[i] = (byte)((byte)inputs_x[i] ^ (byte)list1[i]);
                    }
                }

            }
            // Print Output
            {
                for (int i = 0; i < 128; i++)
                //for (int i = 0; i < int.Parse(temp__[0].ToString()); i++)
                {
                    Console.Write((char)inputs_x[i]);
                }
            }
        }
    }
}
