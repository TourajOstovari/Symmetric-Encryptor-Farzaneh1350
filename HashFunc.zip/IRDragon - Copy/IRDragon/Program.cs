﻿namespace Encryption;
using IRDragon;
using System.Text;
internal class Program
{
    private static void Main()
    {

        Char[] in_x = new char[128]; float q, p, V, w, AlphaV, T, AlphaT; int w2; float SUM_X = 0; string Password_ = ""; string OVO_ = "";
        Console.WriteLine("\nEnter q: (ex: 1.5)\n");
        q = float.Parse(Console.ReadLine());
        Console.WriteLine("\nEnter p: (ex: 2.6)\n");
        p = float.Parse(Console.ReadLine());
        Console.WriteLine("\nEnter w: (55.5)\n");
        w = float.Parse(Console.ReadLine());
        Console.WriteLine("\nEnter V: (1 -- ~)\n");
        V = float.Parse(Console.ReadLine());
        Console.WriteLine("\nEnter Alpha V: (1 -- ~)\n");
        AlphaV = float.Parse(Console.ReadLine());
        Console.WriteLine("\nEnter T: (1 -- ~)\n");
        T = float.Parse(Console.ReadLine());
        Console.WriteLine("\nEnter Alpha T: (1 -- ~)\n");
        AlphaT = float.Parse(Console.ReadLine());
        w2 = (int)w % 2;
        Console.WriteLine("Enter Password: ");
        Password_ = Console.ReadLine();

        Console.WriteLine("\nEnter OVO:\n");
        OVO_ = Console.ReadLine();

        byte[] R1 = Odessa_512_hash_function.Class1.Generator(null, UTF8Encoding.UTF8.GetBytes(Password_));
        byte[] R2 = Odessa_512_hash_function.Class1.Generator(null, R1);
        byte[] R3 = Odessa_512_hash_function.Class1.Generator(null, R2);
        byte[] R4 = Odessa_512_hash_function.Class1.Generator(null, R3);
        byte[] R5 = Odessa_512_hash_function.Class1.Generator(null, R4);
        byte[] R6 = Odessa_512_hash_function.Class1.Generator(null, R5);
        byte[] R7 = Odessa_512_hash_function.Class1.Generator(null, R6);
        {
            Console.WriteLine("\nPlease write TEXT here: \n");
        }
        in_x = Console.ReadLine().ToArray<char>();
        {
            GC.WaitForFullGCComplete();
            byte[] inputs_x = new byte[128];
            int i__ = 0;
            for (; i__ < 128; i__++)
            {
                try
                {
                    inputs_x[i__] = (byte)in_x[i__];
                }
                catch (Exception)
                {

                    break;
                }
            }
            for (; i__ < 128; i__++)
            {
                inputs_x[i__] = 1;
            }
            // ROUND ONE
            {
                Console.WriteLine("\n::Processing::\n");
                dynamic KEY = ((V + (SUM_X + AlphaT) + SUM_X + q + Math.Log10(p) + Math.Pow(w, w2)) * Math.Log10(w));
                byte[] list = new byte[128];
                System.Random rnd = new System.Random((int)KEY);
                // First Round XOR
                {
                    for (int i = 0; i < 128; i++)
                    {
                        rnd.NextBytes(list);
                    }
                    for (int i = 0; i < 128; i++)
                    {
                        inputs_x[i] = (byte)((byte)inputs_x[i] ^ (byte)list[i]);
                        inputs_x[i] = (byte)((byte)inputs_x[i] ^ (byte)R1[i]);
                    }
                }
                // ROUND TWO - ~
                {
                    {
                        SUM_X = (float)KEY; q *= 2; AlphaT += T; V += AlphaV;
                        KEY = ((V + (SUM_X + AlphaT) + SUM_X + q + Math.Log10(p) + Math.Pow(w, w2)) * Math.Log10(w));
                        list = new byte[128];
                        rnd = new System.Random((int)KEY);
                        // Round XOR
                        {
                            for (int i = 0; i < 128; i++)
                            {
                                rnd.NextBytes(list);
                            }
                            for (int i = 0; i < 128; i++)
                            {
                                inputs_x[i] = (byte)((byte)inputs_x[i] ^ (byte)list[i]);
                                inputs_x[i] = (byte)((byte)inputs_x[i] ^ (byte)R2[i]);
                            }
                        }
                    }
                }
                {
                    {
                        SUM_X = (float)KEY; q *= 2; AlphaT += T; V += AlphaV;
                        KEY = ((V + (SUM_X + AlphaT) + SUM_X + q + Math.Log10(p) + Math.Pow(w, w2)) * Math.Log10(w));
                        list = new byte[128];
                        rnd = new System.Random((int)KEY);
                        // Round XOR
                        {
                            for (int i = 0; i < 128; i++)
                            {
                                rnd.NextBytes(list);
                            }
                            for (int i = 0; i < 128; i++)
                            {
                                inputs_x[i] = (byte)((byte)inputs_x[i] ^ (byte)list[i]);
                                inputs_x[i] = (byte)((byte)inputs_x[i] ^ (byte)R3[i]);
                                inputs_x[i] = (byte)((byte)inputs_x[i] ^ (byte)R4[i]);
                                inputs_x[i] = (byte)((byte)inputs_x[i] ^ (byte)R5[i]);
                                inputs_x[i] = (byte)((byte)inputs_x[i] ^ (byte)R6[i]);
                                inputs_x[i] = (byte)((byte)inputs_x[i] ^ (byte)R7[i]);
                            }
                        }
                    }
                }
            }
            // Print Output
            {
                {
                    byte[] OVO_Byte = Odessa_512_hash_function.Class1.Generator(OVO_, null);
                    for (int i = 0; i < 128; i++)
                    {
                        inputs_x[i] = (byte)((byte)inputs_x[i] ^ OVO_Byte[i]);
                    }
                    OVO_Byte = Odessa_512_hash_function.Class1.Generator(null, OVO_Byte);
                    for (int i = 0; i < 128; i++)
                    {
                        inputs_x[i] = (byte)((byte)inputs_x[i] ^ OVO_Byte[i]);
                    }
                }
                //Console.Write(string.Concat(in_x.Length,"!:~~:!"));
                for (int i = 0; i < 128; i++)
                {
                    Console.Write((char)inputs_x[i]);
                }
                System.IO.File.WriteAllBytes(@"D:\Encrypted.txt", inputs_x);
            }
            Console.WriteLine();
            Console.ReadLine();
            new Decryption().Dec();
        }
    }
}
